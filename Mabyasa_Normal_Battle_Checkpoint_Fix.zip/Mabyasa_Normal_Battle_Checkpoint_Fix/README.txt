MABIYASA - NORMAL BATTLE CHECKPOINT FIX

This patch fixes normal battle defeats so the player returns to the registered checkpoint instead of only closing the battle screen.

Changes:
- Normal battle defeat: the Continue button becomes "Return to Checkpoint" and restores the existing checkpoint.
- Normal battle victory: Continue still closes the battle screen without teleporting.
- Checkpoint fallback: every battle ensures a checkpoint exists, while preserving an already registered checkpoint.
- Boss battle flow and combat damage/turn logic are not otherwise changed.

Install (recommended):
1. Close Godot.
2. Put this patch file in your project's root folder (the folder containing project.godot).
3. Open a terminal in that folder and run:
   git apply Mabyasa_Normal_Battle_Checkpoint_Fix.patch
4. Reopen Godot and test both a normal battle defeat and a normal battle victory.

If you do not use Git for local changes, make the matching edits manually in:
- Scenes/Battle/BattleScreen.gd
- Scripts/Battle/BattleManager.gd

This patch targets the current main-branch source. Back up those two scripts first if your local versions have additional edits.

Godot was not available in this environment, so the game has not been runtime-tested here.
